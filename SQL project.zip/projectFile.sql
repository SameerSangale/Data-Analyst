drop table if exists books;
create table if not exists books
(
Book_ID int primary key,
Title varchar(100),
Author varchar(100),
Genre varchar(100),
Published_Year int,
Price numeric,
Stock numeric
);

copy books
from 'C:\Tool\Project\New folder\Books.csv'
delimiter','
csv header;

create table Customers
(
Customer_ID int primary key,
Name varchar(100),
Email varchar(100),
Phone varchar(100),
City varchar(100),
Country varchar(100)
);

copy Customers
from 'C:\Tool\Project\New folder\Customers.csv'
delimiter','
csv header;

drop table orders
create table orders
(
Order_ID int primary key,
Customer_ID int references customers(Customer_ID),
Book_ID int references Books(Book_ID),
Order_Date date,
Quantity bigint,
Total_Amount money
);

copy Orders
from 'C:\Tool\Project\New folder\Orders.csv'
delimiter','
csv header;

select * from orders;
select * from Customers;
select * from Books;

---Basic Q1 Retrieve all books in the "Fiction" genre
select * from Books
where genre='Fiction';

-----Basic Q2 Find books published after the year 1950
select * from Books
where published_year>1950
order by published_year;

---Basic Q3 List all customers from Canada
select * from Customers;

select name, Country from Customers
where lower(country)='canada';

---Basic Q4 Show orders placed in November 2023
select * from orders;
select * from Customers;
select * from Books;

select * from orders
where order_date between '2023-11-01' and '2023-11-30';

---Basic Q5 Retrieve the total stock of books available
select * from orders;
select * from Customers;
select * from Books;

select sum(stock) as total_stock from Books;

---Basic Q6 Find the details of the most expensive book
select * from orders;
select * from Customers;
select * from Books;

select * from Books 
order by price desc limit 1;

---Basic Q7 Show all customers who ordered more than 1 quantity of a book

select customer_id, book_id, quantity from orders
where quantity>1;

---Basic Q8 Retrieve all orders where the total amount exceeds $50
select * from orders
where total_amount>50::money ORDER BY total_amount;

---Basic Q9 List all genres available in the Books table
select distinct genre from books;

---Basic Q10 Find the book with the lowest stock
select * from Books 
order by stock limit 1;

---Basic Q11 Calculate the total revenue generated from all orders
select sum(Total_amount) as Total_Revenue from Orders; 


-----Advance Queries

---Advance Q1 Retrieve the total number of books sold for each genre
Select * from books
Select * from Orders

select books.genre, Sum(orders.quantity) as Total_bookSold from orders
join books on
orders.book_id=books.book_id
group by books.genre;

---Advance Q2 Find the average price of books in the "Fantasy" genre
Select * from books
Select * from Orders

select genre, AVG(Price) as Avg_Price from Books
where genre='Fantasy'
group by genre;

---Advance Q3 List customers who have placed at least 2 orders
Select * from Customers
Select * from Orders

select c.Name, o.customer_id, count(o.order_id) as Order_Placed from
customers c join orders o 
on c.customer_id=o.customer_id
group by c.name,o.customer_id
having Count(o.order_id) >= 2;

---Advance Q4 Find the most frequently ordered book
Select * from Customers
Select * from Orders
Select * from Books

select b.title, o.book_id, count(o.order_id) as Frequently_Ordered from orders o
join books b
on b.book_id=o.book_id
group by o.book_id, b.title
order by count(o.order_id) desc;

---Advance Q5 Show the top 3 most expensive books of 'Fantasy' genre
Select * from books
Select * from Orders

select * from Books
where genre='Fantasy'
order by price desc limit 3;

---Advance Q6 Retrieve the total quantity of books sold by each author
select b.author,sum(o.quantity) as TotalQuantitySold from books b
join orders o
on b.book_id=o.order_id
group by b.author;

---Advance Q7 List the cities where customers who spent over $30 are located
Select * from books
Select * from Orders
Select * from Customers

select c.city,o.Total_amount from orders o
join customers c
on c.customer_id=o.customer_id
where o.total_amount::numeric > 30
group by distinct c.city,o.total_amount
order by o.total_amount::numeric;

---Advance Q8 Find the customer who spent the most on orders
select c.customer_id,c.name,o.Total_amount AS Total_Spent
from customers c join orders o
on c.customer_id=o.customer_id
group by c.customer_id,c.name,o.total_amount
order by Total_Spent desc;

---Advance Q9 Calculate the stock remaining after fulfilling all orders
select b.book_id,b.stock, coalesce(sum(o.quantity),0) as order_quantity, b.stock-coalesce(sum(o.quantity),0) as Remaining_stock
from books b left join orders o
on b.book_id=o.book_id
group by b.book_id,b.stock,o.quantity;